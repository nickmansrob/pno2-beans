class MenuItem {
  final String text;

  const MenuItem({
    required this.text,
  });
}
